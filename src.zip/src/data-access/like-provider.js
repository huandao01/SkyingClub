import { API } from "@src/constants";
import baseProvider from "./base-provider";

export default {
  ...baseProvider(API.like),
};
