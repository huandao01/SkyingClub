export const dataHistorySearch = ["Bom hạt nhân", "Bom nguyên tử"];
