import React from "react";
import { WrapperStyled } from "./styled";

const ProductLink = (props) => {
  return (
    <WrapperStyled>
     
    </WrapperStyled>
  );
};

export default ProductLink;
