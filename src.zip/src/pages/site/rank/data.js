export const rank = [
  {
    id: 1,
    fullName: "Duy Trường",
    point: 3000,
  },
  {
    id: 2,
    fullName: "Đào Huân",
    point: 2511,
  },
  {
    id: 3,
    fullName: "Ngô Hiếu",
    point: 2510,
  },
];
