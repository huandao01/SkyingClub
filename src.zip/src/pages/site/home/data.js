export const postData = [
  {
    author: "Duy Trường",
    timestamp: "1 Giờ",
    content: `Giảng viên said: Còn cái gì em mang ra dùng nốt luôn đi 😒.Năm
        hết tết đến rồi ông nào còn nợ còn vay thì tự giác đê, cứ phải
        nói nói đau hết cả đầu.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến đi`,
    imgUrl: "https://www.w3schools.com/w3images/map.jpg",
    numberLike: 100,
    numberComment: 96,
  },
  {
    author: "Ngô Hiếu",
    timestamp: "6 Giờ",
    content: `Giảng viên said: Còn cái gì em mang ra dùng nốt luôn đi 😒.Năm
        hết tết đến rồi ông nào còn nợ còn vay thì tự giác đê, cứ phải
        nói nói đau hết cả đầu.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến đi`,
    imgUrl: "https://www.w3schools.com/w3images/map.jpg",
    numberLike: 1000,
    numberComment: 906,
  },
  {
    author: "Duy Trường",
    timestamp: "12 Giờ",
    content: `Giảng viên said: Còn cái gì em mang ra dùng nốt luôn đi 😒.Năm
        hết tết đến rồi ông nào còn nợ còn vay thì tự giác đê, cứ phải
        nói nói đau hết cả đầu.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến
        đi.BRIXTON - Vì cuộc đời là những chuyến đi.BRIXTON - Vì cuộc
        đời là những chuyến đi.BRIXTON - Vì cuộc đời là những chuyến đi`,
    imgUrl: "https://www.w3schools.com/w3images/map.jpg",
    numberLike: 1200,
    numberComment: 50,
  },
];

export const productData = [
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
  {
    imgUrl:
      "https://app.lotuscdn.vn/thumb_w/750/2020/5/12/bqt5baharu3ivv8dg2s0_tructiepncov.jpg",
    content: `Iphone 13 promax Iphone 13 promax Iphone 13 promax Iphone 13
        promax Iphone 13 promax`,
  },
];
